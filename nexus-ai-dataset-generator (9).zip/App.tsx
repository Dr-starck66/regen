import React, { useState, useCallback, useMemo } from 'react';
import { 
  TaskType, 
  ResponseLength, 
  Complexity, 
  GenerationConfig, 
  DatasetItem, 
  GenerationState 
} from './types';
import { generateDatasetBatch, refineDatasetItem, evaluateDataset } from './services/geminiService';
import { Loader2, Download, Copy, Trash2, Plus, Search, RefreshCw, XCircle, FileText, CheckCircle2 } from 'lucide-react';
import Papa from 'papaparse';

// Utility Components
const Card: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = "" }) => (
  <div className={`bg-slate-900/60 border border-slate-800 rounded-2xl p-6 backdrop-blur-xl ${className}`}>
    <h2 className="text-xl font-bold text-blue-400 mb-6 flex items-center gap-2">
      {title}
    </h2>
    {children}
  </div>
);

const Label: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <label className="block text-sm font-semibold text-slate-400 mb-2 uppercase tracking-wider">
    {children}
  </label>
);

const App: React.FC = () => {
  // State
  const [config, setConfig] = useState<GenerationConfig>({
    topic: '',
    context: '',
    task: TaskType.QA,
    count: 10,
    length: ResponseLength.MEDIUM,
    complexity: Complexity.INTERMEDIATE,
    style: 'Professional',
    diversity: 'High',
    temperature: 0.7,
    includeMetadata: true
  });

  const [dataset, setDataset] = useState<DatasetItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [refiningIndices, setRefiningIndices] = useState<Set<number>>(new Set());
  const abortControllerRef = React.useRef<AbortController | null>(null);
  const [genState, setGenState] = useState<GenerationState>({
    isGenerating: false,
    progress: 0,
    currentBatch: 0,
    totalBatches: 0,
    error: null
  });

  // Derived Stats
  const filteredDataset = useMemo(() => {
    if (!searchQuery) return dataset;
    const q = searchQuery.toLowerCase();
    return dataset.filter(item => 
      item.instruction.toLowerCase().includes(q) || 
      item.output.toLowerCase().includes(q)
    );
  }, [dataset, searchQuery]);

  const stats = useMemo(() => {
    const size = new Blob([JSON.stringify(dataset)]).size;
    const formattedSize = size > 1024 * 1024 
      ? `${(size / (1024 * 1024)).toFixed(2)} MB` 
      : `${(size / 1024).toFixed(1)} KB`;
    
    return {
      count: dataset.length,
      size: formattedSize,
      quality: dataset.length > 0 ? 'Production' : '—'
    };
  }, [dataset]);

  // Actions
  const [showPreview, setShowPreview] = useState(false);
  const [customTemplates, setCustomTemplates] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('nexus-templates');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });

  const saveCurrentAsTemplate = () => {
    const name = prompt("Nom du modèle ?");
    if (!name) return;
    const newTemplate = { name, config: { ...config } };
    const updated = [...customTemplates, newTemplate];
    setCustomTemplates(updated);
    localStorage.setItem('nexus-templates', JSON.stringify(updated));
  };
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evalResult, setEvalResult] = useState<any>(null);
  
  const handleEvaluate = async () => {
    if (dataset.length === 0) return;
    setIsEvaluating(true);
    setEvalResult(null);
    try {
      const result = await evaluateDataset(config, dataset);
      setEvalResult(result);
    } catch (err: any) {
      alert("Erreur d'évaluation : " + err.message);
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
  };

  const handleRefine = async (index: number) => {
    const item = filteredDataset[index];
    if (!item) return;

    // We need to find the real index in standard dataset to update it correctly
    const realIndex = dataset.indexOf(item);
    if (realIndex === -1) return;

    setRefiningIndices(prev => new Set(prev).add(index));
    try {
      const refinedItem = await refineDatasetItem(config, item);
      setDataset(prev => {
        const next = [...prev];
        next[realIndex] = refinedItem;
        return next;
      });
    } catch (err: any) {
      alert("Erreur de raffinement : " + err.message);
    } finally {
      setRefiningIndices(prev => {
        const next = new Set(prev);
        next.delete(index);
        return next;
      });
    }
  };

  const handleGenerate = async (append: boolean = false) => {
    if (!config.topic) {
      setGenState(prev => ({ ...prev, error: "Veuillez entrer un domaine/thème." }));
      return;
    }

    if (!append) {
      setDataset([]);
    }
    
    setGenState({
      isGenerating: true,
      progress: 0,
      currentBatch: 0,
      totalBatches: Math.ceil(config.count / 5),
      error: null
    });

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();

    const batchSize = 5;
    const totalBatches = Math.ceil(config.count / batchSize);
    let accumulated: DatasetItem[] = append ? [...dataset] : [];

    try {
      for (let i = 0; i < totalBatches; i++) {
        if (abortControllerRef.current?.signal.aborted) break;

        const currentBatchSize = Math.min(batchSize, config.count - (i * batchSize));
        
        // Pick some previous examples for diversity context
        const recentExamples = accumulated.slice(-5).map(ex => `Q: ${ex.instruction.substring(0, 50)}...`).join('\\n');

        const newBatch = await generateDatasetBatch(config, currentBatchSize, i, recentExamples, abortControllerRef.current.signal);
        accumulated = [...accumulated, ...newBatch];
        
        // Progressive update (batched by React)
        setDataset(accumulated); 
        setGenState(prev => ({
          ...prev,
          currentBatch: i + 1,
          progress: Math.round(((i + 1) / totalBatches) * 100)
        }));
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Generation aborted');
      } else {
        setGenState(prev => ({ ...prev, error: err.message }));
      }
    } finally {
      setGenState(prev => ({ ...prev, isGenerating: false }));
      abortControllerRef.current = null;
    }
  };

  const copyToClipboard = () => {
    const jsonl = filteredDataset.map(item => JSON.stringify(item)).join('\n');
    navigator.clipboard.writeText(jsonl);
    alert('Dataset copié (JSONL) !');
  };

  const downloadJSONL = () => {
    const jsonl = filteredDataset.map(item => JSON.stringify(item)).join('\n');
    const blob = new Blob([jsonl], { type: 'application/x-ndjson' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus-${config.topic.toLowerCase().replace(/\s+/g, '-')}.jsonl`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadCSV = () => {
    const csv = Papa.unparse(filteredDataset.map(item => ({
      instruction: item.instruction,
      output: item.output,
      difficulty: item.metadata?.difficulty || 'unknown',
      subcategory: item.metadata?.subcategory || 'unknown',
      quality_score: item.metadata?.quality_score || 0
    })));
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus-${config.topic.toLowerCase().replace(/\s+/g, '-')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Virtualized Row Render
  const Row = ({ index, style }: { index: number, style: React.CSSProperties }) => {
    const item = filteredDataset[index];
    const isRefining = refiningIndices.has(index);

    return (
      <div style={style} className="pr-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 h-[180px] flex flex-col gap-2 shadow-sm font-mono text-xs overflow-hidden relative group">
          <div className="flex justify-between items-center text-slate-500 border-b border-slate-800 pb-2 mb-1 shrink-0">
            <span className="text-blue-400/80">#{index + 1}</span>
            <div className="flex items-center gap-4">
              {item.metadata && (
                <div className="flex gap-3 text-[10px] uppercase">
                  <span>Dif: <span className="text-emerald-400">{item.metadata.difficulty}</span></span>
                  <span>Sub: <span className="text-fuchsia-400">{item.metadata.subcategory}</span></span>
                  <span>Score: <span className="text-amber-400">{item.metadata.quality_score}</span></span>
                </div>
              )}
              <button 
                onClick={() => handleRefine(index)} 
                disabled={isRefining}
                className="opacity-0 group-hover:opacity-100 transition-opacity bg-blue-500/20 text-blue-400 p-1 rounded-md hover:bg-blue-500/40 disabled:opacity-50"
                title="Raffiner (Améliorer avec IA)"
              >
                <RefreshCw className={`w-3 h-3 ${isRefining ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
          <div className="overflow-y-auto pr-2 scrollbar-thin flex-1 text-slate-300">
            <p className="mb-2"><span className="text-blue-400 font-bold">"instruction":</span> "{item.instruction}"</p>
            <p><span className="text-blue-400 font-bold">"output":</span> "{item.output}"</p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <header className="text-center mb-12 bg-blue-500/5 border border-blue-500/20 rounded-3xl p-8 backdrop-blur-md">
        <h1 className="text-4xl md:text-5xl font-black mb-4 bg-gradient-to-r from-blue-400 to-fuchsia-500 bg-clip-text text-transparent">
          🚀 NEXUS AI DATASET GENERATOR
        </h1>
        <p className="text-slate-400 text-lg mb-6">
          Générez des jeux de données synthétiques haute fidélité avec Gemini 3.5 Flash.
        </p>
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/30 rounded-full text-emerald-400 font-bold text-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          SYSTÈME OPÉRATIONNEL • BACKEND ACTIF
        </div>
      </header>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
        
        {/* Config Column */}
        <div className="col-span-1 lg:col-span-5 space-y-6">
          <Card title="⚙️ Configuration Principale">
            <div className="space-y-4">
              
              {/* Templates Selection */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4">
                <div className="flex justify-between items-center mb-3">
                  <Label>Modèles Prédéfinis & Personnalisés</Label>
                  <button 
                    onClick={saveCurrentAsTemplate}
                    className="text-xs text-blue-400 hover:text-blue-300 underline"
                  >
                    + Sauvegarder l'actuel
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button 
                    onClick={() => setConfig({...config, task: TaskType.QA, length: ResponseLength.SHORT, complexity: Complexity.BEGINNER, style: "Direct and helpful", diversity: "Moderate", temperature: 0.7})}
                    className="px-3 py-1.5 text-xs font-bold rounded-lg bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/20 transition-all"
                  >
                    Alpaca QA
                  </button>
                  <button 
                    onClick={() => setConfig({...config, task: TaskType.DIALOGUE, length: ResponseLength.LONG, complexity: Complexity.ADVANCED, style: "Conversational, human-like", diversity: "High", temperature: 0.9})}
                    className="px-3 py-1.5 text-xs font-bold rounded-lg bg-fuchsia-500/10 text-fuchsia-400 hover:bg-fuchsia-500/20 border border-fuchsia-500/20 transition-all"
                  >
                    UltraChat
                  </button>
                  <button 
                    onClick={() => setConfig({...config, task: TaskType.REASONING, length: ResponseLength.LONG, complexity: Complexity.EXPERT, style: "Step-by-step logical", diversity: "Moderate", temperature: 0.3})}
                    className="px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20 transition-all"
                  >
                    Orca Math
                  </button>
                  {customTemplates.map((t, idx) => (
                    <button 
                      key={idx}
                      onClick={() => setConfig(t.config)}
                      className="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 transition-all"
                    >
                      {t.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Domaine / Thème</Label>
                <input 
                  type="text" 
                  className="w-full bg-slate-950/50 border border-slate-700 rounded-xl px-4 py-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all outline-none"
                  placeholder="Ex: Machine Learning, Histoire..."
                  value={config.topic}
                  onChange={(e) => setConfig({ ...config, topic: e.target.value })}
                />
              </div>
              <div>
                <Label>Contexte Additionnel</Label>
                <textarea 
                  className="w-full bg-slate-950/50 border border-slate-700 rounded-xl px-4 py-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all outline-none min-h-[80px]"
                  placeholder="Contraintes spécifiques..."
                  value={config.context}
                  onChange={(e) => setConfig({ ...config, context: e.target.value })}
                />
              </div>
              <div>
                <Label>Nombre d'exemples à générer ({config.count})</Label>
                <input 
                  type="range" 
                  min="1" max="500" 
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  value={config.count}
                  onChange={(e) => setConfig({ ...config, count: parseInt(e.target.value) })}
                />
                <div className="flex justify-between text-xs text-slate-500 mt-1 font-mono">
                  <span>1</span>
                  <span>Max: 500</span>
                </div>
              </div>

              <div className="pt-4 flex flex-col gap-3">
                <button 
                  onClick={() => setShowPreview(!showPreview)}
                  className="w-full py-2 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700 active:scale-95 transition-all text-sm flex items-center justify-center gap-2 border border-slate-700"
                >
                  <FileText className="w-4 h-4" />
                  {showPreview ? "Cacher le Prompt" : "Prévisualiser le Prompt"}
                </button>

                {showPreview && (
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-400 overflow-y-auto max-h-[300px] scrollbar-thin">
                    <p className="text-blue-400 mb-2">// System Instruction</p>
                    <p>Tu es un ingénieur expert en génération de données synthétiques...</p>
                    <p className="text-emerald-400 mt-4 mb-2">// User Prompt Preview</p>
                    <p>Génère EXACTEMENT 5 exemples de haute qualité.</p>
                    <p>TOPIC PRINCIPAL : {config.topic || '[VIDE]'}</p>
                    <p>TYPE DE TÂCHE : {config.task}</p>
                    <p>CONTEXTE : {config.context || 'Général'}</p>
                    <p>LONGUEUR : {config.length}</p>
                    <p>COMPLEXITÉ : {config.complexity}</p>
                    <p>STYLE : {config.style}</p>
                    <p>DIVERSITÉ : {config.diversity}</p>
                    <p>TEMPÉRATURE : {config.temperature !== undefined ? config.temperature : 'Auto'}</p>
                  </div>
                )}

                {!genState.isGenerating ? (
                  <button 
                    onClick={() => handleGenerate(false)}
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black text-lg hover:shadow-lg hover:shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-widest flex items-center justify-center gap-3"
                  >
                    ⚡ Nouvelle Génération
                  </button>
                ) : (
                  <button 
                    onClick={handleStop}
                    className="w-full py-4 rounded-xl bg-red-600/20 text-red-500 font-black text-lg hover:bg-red-600/30 active:scale-95 transition-all uppercase tracking-widest flex items-center justify-center gap-3 border border-red-500/50"
                  >
                    <Loader2 className="w-6 h-6 outline-none animate-spin" />
                    Arrêter ({genState.progress}%)
                  </button>
                )}
                
                <button 
                  disabled={genState.isGenerating || dataset.length === 0}
                  onClick={() => handleGenerate(true)}
                  className="w-full py-3 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-700 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 border border-slate-700"
                >
                  <Plus className="w-5 h-5" />
                  Ajouter plus d'exemples
                </button>
              </div>

              {genState.error && (
                <p className="text-red-400 text-sm mt-2 text-center bg-red-500/10 p-3 rounded-xl border border-red-500/20">
                  {genState.error}
                </p>
              )}
            </div>
          </Card>

          <Card title="🎨 Ajustements Développeur">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Tâche</Label>
                  <select className="w-full bg-slate-950/50 border border-slate-700 rounded-xl px-4 py-2 outline-none text-sm" value={config.task} onChange={(e) => setConfig({ ...config, task: e.target.value as TaskType })}>
                    {Object.values(TaskType).map(t => <option key={t} value={t}>{t.toUpperCase()}</option>)}
                  </select>
                </div>
                <div>
                  <Label>Température</Label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" min="0" max="1.5" step="0.1" 
                      className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-fuchsia-500"
                      value={config.temperature !== undefined ? config.temperature : 0.7}
                      onChange={(e) => setConfig({ ...config, temperature: parseFloat(e.target.value) })}
                    />
                    <span className="text-xs font-mono text-fuchsia-400 w-8 text-right">
                      {config.temperature !== undefined ? config.temperature : 0.7}
                    </span>
                  </div>
                </div>
                <div>
                  <Label>Longueur</Label>
                  <select className="w-full bg-slate-950/50 border border-slate-700 rounded-xl px-4 py-2 outline-none text-sm" value={config.length} onChange={(e) => setConfig({ ...config, length: e.target.value as ResponseLength })}>
                    {Object.values(ResponseLength).map(l => <option key={l} value={l}>{l.toUpperCase()}</option>)}
                  </select>
                </div>
                <div>
                  <Label>Complexité</Label>
                  <select className="w-full bg-slate-950/50 border border-slate-700 rounded-xl px-4 py-2 outline-none text-sm" value={config.complexity} onChange={(e) => setConfig({ ...config, complexity: e.target.value as Complexity })}>
                    {Object.values(Complexity).map(c => <option key={c} value={c}>{c.toUpperCase()}</option>)}
                  </select>
                </div>
                <div>
                  <Label>Diversité</Label>
                  <select 
                    className="w-full bg-slate-950/50 border border-slate-700 rounded-xl px-4 py-2 outline-none text-sm" 
                    value={config.diversity} 
                    onChange={(e) => {
                      const val = e.target.value;
                      let temp = 0.7;
                      if (val === 'Moderate') temp = 0.7;
                      if (val === 'High') temp = 0.85;
                      if (val === 'Maximum') temp = 0.95;
                      setConfig({ ...config, diversity: val, temperature: temp });
                    }}
                  >
                    <option>Moderate</option>
                    <option>High</option>
                    <option>Maximum</option>
                  </select>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Dataset Column */}
        <div className="col-span-1 lg:col-span-7 flex flex-col space-y-6">
          
          {/* Progress Banner */}
          {genState.isGenerating && (
            <div className="p-6 bg-blue-500/10 border border-blue-500/20 rounded-2xl flex items-center gap-6">
              <Loader2 className="w-10 h-10 text-blue-400 animate-spin shrink-0" />
              <div className="flex-1">
                <div className="flex justify-between items-end mb-2">
                  <div>
                    <h3 className="text-blue-400 font-black tracking-wide">GÉNÉRATION EN COURS...</h3>
                    <p className="text-slate-400 text-sm">Traitement du lot {genState.currentBatch} sur {genState.totalBatches}</p>
                  </div>
                  <span className="text-2xl font-black text-blue-400">{genState.progress}%</span>
                </div>
                <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-fuchsia-500 transition-all duration-500" 
                    style={{ width: `${genState.progress}%` }}
                  />
                </div>
              </div>
            </div>
          )}

          <Card title="📄 Explorer le Dataset" className="flex-1 flex flex-col">
            
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
              <div className="flex gap-4">
                <div className="flex gap-2">
                   <span className="text-slate-500 text-sm font-bold uppercase">Total:</span> 
                   <span className="text-emerald-400 font-mono font-bold">{dataset.length}</span>
                </div>
                <div className="flex gap-2">
                   <span className="text-slate-500 text-sm font-bold uppercase">Taille:</span> 
                   <span className="text-blue-400 font-mono font-bold">{stats.size}</span>
                </div>
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Rechercher (Preview)..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950/50 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-sm focus:border-blue-500 outline-none transition-all placeholder-slate-600"
                />
              </div>
            </div>

            {/* Virtualized Render Area */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex-1 min-h-[450px]">
              {filteredDataset.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center opacity-40 py-20 text-center">
                  <span className="text-5xl mb-4">📭</span>
                  <p className="text-lg">Le dataset est vide.</p>
                  <p className="text-sm">Lancez une génération pour commencer.</p>
                </div>
              ) : (
                <div className="h-[450px] overflow-y-auto scrollbar-thin">
                  {filteredDataset.map((item, index) => (
                    <div key={`item-${index}`} style={{ height: 200 }}>
                      <Row index={index} style={{ height: '100%' }} />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Evaluation Results */}
            {evalResult && (
              <div className="mt-4 p-4 bg-indigo-500/10 border border-indigo-500/30 rounded-xl">
                <div className="flex items-center gap-3 mb-2">
                  <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                  <h3 className="font-bold text-indigo-400 text-lg">Évaluation (Score: {evalResult.score}/10)</h3>
                </div>
                <p className="text-sm text-slate-300 mb-3">{evalResult.feedback}</p>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <strong className="text-emerald-400 block mb-1">Points forts :</strong>
                    <ul className="list-disc pl-4 text-slate-400">
                      {evalResult.strengths?.map((s: string, i: number) => <li key={i}>{s}</li>)}
                    </ul>
                  </div>
                  <div>
                    <strong className="text-red-400 block mb-1">Points faibles :</strong>
                    <ul className="list-disc pl-4 text-slate-400">
                      {evalResult.weaknesses?.map((w: string, i: number) => <li key={i}>{w}</li>)}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Actions Toolbar */}
            <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-slate-800">
              <button 
                onClick={handleEvaluate}
                disabled={dataset.length === 0 || isEvaluating}
                className="flex-1 min-w-[140px] px-4 py-3 rounded-xl bg-indigo-600/20 text-indigo-400 font-bold hover:bg-indigo-600/30 border border-indigo-500/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isEvaluating ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                Évaluer (IA)
              </button>
              <button 
                onClick={copyToClipboard}
                disabled={dataset.length === 0}
                className="flex-1 min-w-[140px] px-4 py-3 rounded-xl bg-slate-800 text-white font-bold hover:bg-slate-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Copy className="w-4 h-4" /> Copier JSONL
              </button>
              <button 
                onClick={downloadJSONL}
                disabled={dataset.length === 0}
                className="flex-1 min-w-[140px] px-4 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-500 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Download className="w-4 h-4" /> Exporter JSONL
              </button>
              <button 
                onClick={downloadCSV}
                disabled={dataset.length === 0}
                className="flex-1 min-w-[140px] px-4 py-3 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Download className="w-4 h-4" /> Exporter CSV
              </button>
              <button 
                onClick={() => {
                  if(confirm('Effacer toutes les données ?')) setDataset([]);
                }}
                disabled={dataset.length === 0}
                className="px-4 py-3 rounded-xl bg-red-500/10 text-red-500 font-bold hover:bg-red-500/20 transition-all flex items-center justify-center disabled:opacity-50"
                title="Effacer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

          </Card>
        </div>
      </div>

    </div>
  );
};

export default App;
