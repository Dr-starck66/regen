
export enum TaskType {
  QA = 'qa',
  INSTRUCTION = 'instruction',
  DIALOGUE = 'dialogue',
  CLASSIFICATION = 'classification',
  GENERATION = 'generation',
  REASONING = 'reasoning'
}

export enum ResponseLength {
  CONCISE = 'concise',
  MEDIUM = 'medium',
  DETAILED = 'detailed',
  COMPREHENSIVE = 'comprehensive'
}

export enum Complexity {
  BEGINNER = 'beginner',
  INTERMEDIATE = 'intermediate',
  ADVANCED = 'advanced',
  EXPERT = 'expert'
}

export interface DatasetItem {
  instruction: string;
  output: string;
  metadata: {
    difficulty: string;
    subcategory: string;
    quality_score: number;
    [key: string]: any;
  };
}

export interface GenerationConfig {
  topic: string;
  context: string;
  task: TaskType;
  count: number;
  length: ResponseLength;
  complexity: Complexity;
  style: string;
  diversity: string;
  temperature?: number;
  includeMetadata?: boolean;
}

export interface GenerationState {
  isGenerating: boolean;
  progress: number;
  currentBatch: number;
  totalBatches: number;
  error: string | null;
}
