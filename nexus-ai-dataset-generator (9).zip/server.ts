import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { generateDataset, validateDataset, enrichDataset, saveDataset, listDatasets, exportDataset } from './src/server/routes';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '100mb' }));

  // API Endpoints
  app.post("/api/generate-dataset", generateDataset);
  app.post("/api/validate-dataset", validateDataset);
  app.post("/api/enrich-dataset", enrichDataset);
  app.post("/api/save-dataset", saveDataset);
  app.get("/api/datasets", listDatasets);
  app.get("/api/export-dataset/:id", exportDataset);

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
