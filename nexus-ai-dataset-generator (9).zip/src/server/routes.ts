import { db } from '../db/index';
import { datasets, datasetSamples } from '../db/schema';
import { GoogleGenAI, Type } from '@google/genai';
import { eq, desc } from 'drizzle-orm';
import { Request, Response } from 'express';
import { generateWithQualityPipeline } from './quality';

const getAI = () => {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("Gemini API key is required");
  return new GoogleGenAI({ apiKey: key });
};

// ... Generation Prompts ...
const getSystemPromptForCategory = (category: string) => {
  const base = `You are a world-class AI researcher and dataset engineer creating high-quality, research-grade synthetic data for LLM fine-tuning.
Output MUST be a valid JSON array of objects. NEVER wrap in markdown code blocks if the client expects raw JSON array.
CRITICAL QUALITY STANDARDS:
- Zero repetition. Highly diverse across different topics, angles, and contexts.
- Absolute factual accuracy and logical consistency. No mathematical or logical hallucinations.
- Deep, nuanced content suitable for expert-level training. Avoid generic or shallow responses.
- Use advanced vocabulary, correct domain-specific terminology, and highly realistic scenarios.
- Output strictly the exact JSON schema requested.
`;
  switch (category) {
    case 'cybersecurity':
      return base + `\nContext: Cybersecurity datasets (phishing detection, malware, intrusion detection, zero-day analysis). Use highly realistic synthetic indicators (IPs, hashes), complex logs, advanced attack scenarios (e.g. APTs), and detailed mitigation strategies. Include classification (e.g. malicious/benign) and severity.`;
    case 'financial':
      return base + `\nContext: Financial AI datasets (market sentiment, earnings analysis, macroeconomic indicators, quantitative modeling). Include specific assets, precise dates, realistic market events, calibrated sentiment scores, and nuanced market impact analysis.`;
    case 'real-estate':
      return base + `\nContext: Real Estate AI datasets (property valuation, rental prediction, investment scoring). Include diverse locations, rich property characteristics, realistic pricing dynamics, rental yields, granular risk scores, and macroeconomic market trends.`;
    case 'seo-marketing':
      return base + `\nContext: SEO and Marketing datasets (keyword intent, content optimization, market segmentation). Include long-tail keywords, nuanced search intents, accurate keyword difficulty estimations, deep semantic clusters, and high-conversion recommended content.`;
    case 'medical':
      return base + `\nContext: Medical and Scientific datasets. IMPORTANT: NO REAL PII. Use 100% synthetic anonymized data. Generate complex medical conversations, expert-level clinical reasoning, differential diagnoses, and accurate pharmacological or biological properties.`;
    case 'computer-vision':
      return base + `\nContext: Computer Vision metadata. Generate highly detailed synthetic object detection annotations, challenging OCR texts, precise bounding box coordinates, and diverse segmentation labels.`;
    default:
      return base + `\nContext: LLM Fine-Tuning datasets (Instruction/Response, Chat, Complex Reasoning). Include challenging instructions, rich input context, step-by-step chain-of-thought reasoning, and a flawless, high-quality final answer.`;
  }
};

const getResponseSchemaForCategory = (category: string) => {
  const meta = { type: Type.OBJECT, properties: { quality_score: { type: Type.NUMBER }, category: { type: Type.STRING } }, required: ["quality_score", "category"] };
  
  if (category === 'cybersecurity') {
    return { type: Type.OBJECT, properties: { attack_scenario: { type: Type.STRING }, indicators: { type: Type.ARRAY, items: { type: Type.STRING } }, logs: { type: Type.STRING }, classification: { type: Type.STRING }, severity: { type: Type.STRING, enum: ["Low", "Medium", "High", "Critical"] }, mitigation: { type: Type.STRING }, metadata: meta }, required: ["attack_scenario", "indicators", "logs", "classification", "severity", "mitigation", "metadata"] };
  } else if (category === 'financial') {
    return { type: Type.OBJECT, properties: { asset: { type: Type.STRING }, date: { type: Type.STRING }, event: { type: Type.STRING }, sentiment_score: { type: Type.NUMBER }, market_impact: { type: Type.STRING }, explanation: { type: Type.STRING }, metadata: meta }, required: ["asset", "date", "event", "sentiment_score", "market_impact", "explanation", "metadata"] };
  } else if (category === 'real-estate') {
    return { type: Type.OBJECT, properties: { location: { type: Type.STRING }, property_characteristics: { type: Type.STRING }, price: { type: Type.NUMBER }, rental_yield: { type: Type.NUMBER }, risk_score: { type: Type.NUMBER }, market_trend: { type: Type.STRING }, metadata: meta }, required: ["location", "property_characteristics", "price", "rental_yield", "risk_score", "market_trend", "metadata"] };
  } else if (category === 'seo-marketing') {
    return { type: Type.OBJECT, properties: { keyword: { type: Type.STRING }, intent: { type: Type.STRING }, difficulty: { type: Type.NUMBER }, recommended_content: { type: Type.STRING }, semantic_cluster: { type: Type.STRING }, metadata: meta }, required: ["keyword", "intent", "difficulty", "recommended_content", "semantic_cluster", "metadata"] };
  } else if (category === 'medical') {
    return { type: Type.OBJECT, properties: { patient_case_synthetic: { type: Type.STRING }, symptoms: { type: Type.ARRAY, items: { type: Type.STRING } }, clinical_reasoning: { type: Type.STRING }, proposed_action: { type: Type.STRING }, disclaimer: { type: Type.STRING }, metadata: meta }, required: ["patient_case_synthetic", "symptoms", "clinical_reasoning", "proposed_action", "disclaimer", "metadata"] };
  } else if (category === 'computer-vision') {
    return { type: Type.OBJECT, properties: { image_description: { type: Type.STRING }, bounding_boxes: { type: Type.ARRAY, items: { type: Type.STRING } }, classification_labels: { type: Type.ARRAY, items: { type: Type.STRING } }, ocr_text: { type: Type.STRING }, metadata: meta }, required: ["image_description", "bounding_boxes", "classification_labels", "ocr_text", "metadata"] };
  } else {
    // Default LLM
    return { type: Type.OBJECT, properties: { instruction: { type: Type.STRING }, context: { type: Type.STRING }, input: { type: Type.STRING }, reasoning: { type: Type.STRING }, answer: { type: Type.STRING }, metadata: meta }, required: ["instruction", "context", "input", "reasoning", "answer", "metadata"] };
  }
};

export async function generateDataset(req: Request, res: Response) {
  try {
    const { category, size, parameters } = req.body;
    
    // Check if Expert Mode is enabled via parameters
    if (parameters?.expertMode) {
      const config = parameters.providerConfig || { provider: 'gemini', model: 'gemini-3.6-pro', temperature: parameters.temperature };
      const schema = getResponseSchemaForCategory(category);
      // Generate items in parallel
      const tasks = Array.from({ length: size || 1 }).map(() => 
        generateWithQualityPipeline(
          category, 
          [config], // Generator
          [config], // Critic
          schema
        )
      );
      
      const results = await Promise.all(tasks);
      // Filter out nulls (rejected items)
      const validSamples = results.filter(r => r !== null);
      
      return res.json({ samples: validSamples });
    }

    // Standard fast generation pipeline
    const ai = getAI();
    const batchSize = Math.min(size || 10, 20); 
    
    const prompt = `Generate exactly ${batchSize} diverse synthetic samples for the category: ${category}.
    Parameters: ${JSON.stringify(parameters)}`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        systemInstruction: getSystemPromptForCategory(category),
        responseMimeType: "application/json",
        temperature: parameters?.temperature ?? 0.9,
        responseSchema: {
          type: Type.ARRAY,
          items: getResponseSchemaForCategory(category)
        }
      }
    });

    let text = response.text || "[]";
    const parsed = JSON.parse(text);
    res.json({ samples: Array.isArray(parsed) ? parsed : [] });
  } catch (error: any) {
    console.error("Generate error:", error);
    res.status(500).json({ error: error.message });
  }
}

export async function validateDataset(req: Request, res: Response) {
  try {
    const { samples, category } = req.body;
    
    // Programmatic validations
    let exactDuplicates = 0;
    const seen = new Set();
    for (const sample of samples) {
      // Create a deterministic string representation for uniqueness check (focusing on core content)
      const contentStr = JSON.stringify(sample);
      if (seen.has(contentStr)) {
        exactDuplicates++;
      }
      seen.add(contentStr);
    }

    const ai = getAI();
    
    // Only send a subset for AI validation to save tokens
    const sampleSubset = samples.slice(0, Math.min(10, samples.length));
    
    const prompt = `Act as a Data Quality Assurance Agent. Review this subset (${sampleSubset.length} items) of a synthetic dataset for the category '${category}'.
Evaluate it for diversity, realism, depth of information, formatting consistency, and potential hallucinations.
Return a rigorous evaluation with a final quality score out of 100.
    
Sample data to review:
${JSON.stringify(sampleSubset)} ... (truncated)`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.1, // Low temp for more consistent evaluation
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            quality_score: { type: Type.NUMBER, description: "0 to 100 based on depth, diversity, and realism" },
            bias_score: { type: Type.NUMBER, description: "1 to 10 where 10 is high bias or lack of diversity" },
            training_ready: { type: Type.BOOLEAN, description: "Whether this meets the bar for LLM fine-tuning" },
            recommended_models: { type: Type.ARRAY, items: { type: Type.STRING } },
            feedback: { type: Type.STRING, description: "Specific critique on the data quality" }
          },
          required: ["quality_score", "bias_score", "training_ready", "recommended_models", "feedback"]
        }
      }
    });

    const aiValidation = JSON.parse(response.text || "{}");
    
    // Combine programmatic checks with AI evaluation
    const finalValidation = {
      ...aiValidation,
      duplicates: exactDuplicates,
      // Penalize quality score if there are many exact duplicates
      quality_score: Math.max(0, (aiValidation.quality_score || 80) - (exactDuplicates * 5))
    };

    res.json(finalValidation);
  } catch (error: any) {
    console.error("Validate error:", error);
    res.status(500).json({ error: error.message });
  }
}

export async function enrichDataset(req: Request, res: Response) {
  try {
    const { samples, category, name } = req.body;
    const ai = getAI();
    
    const prompt = `Act as a Dataset Architect and Marketplace Agent. 
Enrich the metadata for this dataset named "${name}" (category: ${category}).
Generate a professional README.md string (markdown) containing dataset description, use cases, limitations, license, and examples.
Also generate an array of taxonomy tags and a short commercial product description.

Sample data to inform your generation:
${JSON.stringify(samples.slice(0, 3))}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7,
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            readme: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            product_description: { type: Type.STRING },
            estimated_price_euros: { type: Type.NUMBER, description: "Price in Euros based on quality and domain (e.g. 100 to 10000+)" }
          },
          required: ["readme", "tags", "product_description", "estimated_price_euros"]
        }
      }
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
}

export async function saveDataset(req: Request, res: Response) {
  try {
    const { name, category, size, qualityScore, price, format, metadata, samples } = req.body;
    
    const result = await db.insert(datasets).values({
      name,
      category,
      size,
      qualityScore,
      price,
      format,
      metadata,
      trainingReady: metadata?.training_ready || false
    }).returning({ id: datasets.id });
    
    const datasetId = result[0].id;
    
    if (samples && samples.length > 0) {
      // Chunk inserts if too large
      await db.insert(datasetSamples).values(
        samples.map((content: any) => ({
          datasetId,
          content
        }))
      );
    }
    
    res.json({ success: true, id: datasetId });
  } catch (error: any) {
    console.error("Save error:", error);
    res.status(500).json({ error: error.message });
  }
}

export async function exportDataset(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const dataset = await db.select().from(datasets).where(eq(datasets.id, id)).limit(1);
    if (!dataset || dataset.length === 0) return res.status(404).json({ error: "Dataset not found" });

    const samples = await db.select().from(datasetSamples).where(eq(datasetSamples.datasetId, id));

    const exportData = {
      dataset_card: dataset[0].metadata,
      license: dataset[0].license,
      samples: samples.map(s => s.content)
    };

    res.json(exportData);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
}

export async function listDatasets(req: Request, res: Response) {
  try {
    const all = await db.select().from(datasets).orderBy(desc(datasets.createdDate));
    res.json(all);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
}
