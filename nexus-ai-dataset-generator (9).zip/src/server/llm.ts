import { GoogleGenAI } from '@google/genai';
import { LLMProviderName, ProviderConfig } from '../types';

export interface LLMPrompt {
  systemInstruction: string;
  userPrompt: string;
  jsonSchema?: any;
}

export abstract class BaseLLMProvider {
  protected config: ProviderConfig;
  constructor(config: ProviderConfig) {
    this.config = config;
  }
  abstract generate(prompt: LLMPrompt): Promise<string>;
}

export class GeminiProvider extends BaseLLMProvider {
  private ai: GoogleGenAI;
  constructor(config: ProviderConfig) {
    super(config);
    this.ai = new GoogleGenAI({ apiKey: config.apiKey || process.env.GEMINI_API_KEY });
  }
  async generate(prompt: LLMPrompt): Promise<string> {
    const response = await this.ai.models.generateContent({
      model: this.config.model || 'gemini-3.6-pro',
      contents: prompt.userPrompt,
      config: {
        systemInstruction: prompt.systemInstruction,
        temperature: this.config.temperature ?? 0.7,
        responseMimeType: prompt.jsonSchema ? "application/json" : "text/plain",
        responseSchema: prompt.jsonSchema
      }
    });
    return response.text || "";
  }
}

// Stub for other providers
export class OpenAIProvider extends BaseLLMProvider {
  async generate(prompt: LLMPrompt): Promise<string> {
    const apiKey = this.config.apiKey || process.env.OPENAI_API_KEY;
    if (!apiKey) throw new Error("OPENAI_API_KEY is missing");

    const messages = [];
    if (prompt.systemInstruction) {
      messages.push({ role: "system", content: prompt.systemInstruction });
    }
    messages.push({ role: "user", content: prompt.userPrompt });

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: this.config.model || "gpt-4o",
        messages,
        temperature: this.config.temperature ?? 0.7,
        response_format: prompt.jsonSchema ? { type: "json_object" } : undefined
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content || "";
  }
}

export class AnthropicProvider extends BaseLLMProvider {
  async generate(prompt: LLMPrompt): Promise<string> {
    const apiKey = this.config.apiKey || process.env.ANTHROPIC_API_KEY;
    if (!apiKey) throw new Error("ANTHROPIC_API_KEY is missing");

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: this.config.model || "claude-3-5-sonnet-20240620",
        system: prompt.systemInstruction || undefined,
        messages: [{ role: "user", content: prompt.userPrompt }],
        max_tokens: 4096,
        temperature: this.config.temperature ?? 0.7
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Anthropic API error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    return data.content[0].text || "";
  }
}

export class GroqProvider extends BaseLLMProvider {
  async generate(prompt: LLMPrompt): Promise<string> {
    const apiKey = this.config.apiKey || process.env.GROQ_API_KEY;
    if (!apiKey) throw new Error("GROQ_API_KEY is missing");

    const messages = [];
    if (prompt.systemInstruction) {
      messages.push({ role: "system", content: prompt.systemInstruction });
    }
    messages.push({ role: "user", content: prompt.userPrompt });

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: this.config.model || "llama3-70b-8192",
        messages,
        temperature: this.config.temperature ?? 0.7,
        response_format: prompt.jsonSchema ? { type: "json_object" } : undefined
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Groq API error: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    return data.choices[0].message.content || "";
  }
}

export class LLMFactory {
  static getProvider(config: ProviderConfig): BaseLLMProvider {
    switch (config.provider) {
      case 'gemini': return new GeminiProvider(config);
      case 'openai': return new OpenAIProvider(config);
      case 'anthropic': return new AnthropicProvider(config);
      case 'groq': return new GroqProvider(config);
      default: throw new Error(`Provider ${config.provider} unsupported`);
    }
  }

  static async generateWithFallback(
    configs: ProviderConfig[], 
    prompt: LLMPrompt
  ): Promise<string> {
    let lastError: any = null;
    for (const config of configs) {
      try {
        const provider = this.getProvider(config);
        return await provider.generate(prompt);
      } catch (error) {
        console.warn(`[Fallback] Provider ${config.provider} failed:`, error);
        lastError = error;
      }
    }
    throw new Error(`All fallback providers failed. Last error: ${lastError?.message}`);
  }
}