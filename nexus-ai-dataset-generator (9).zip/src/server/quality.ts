import { LLMFactory } from './llm';
import { ProviderConfig, ExpertDatasetItem, QualityScore } from '../types';
import { EXPERT_GENERATION_PROMPT, EXPERT_CRITIQUE_PROMPT } from './prompts';
import crypto from 'crypto';

export async function generateWithQualityPipeline(
  topic: string, 
  generatorConfigs: ProviderConfig[],
  criticConfigs: ProviderConfig[],
  schema: any
): Promise<ExpertDatasetItem | null> {
  let attempt = 0;
  const maxAttempts = 3;
  let previousCritique: string | null = null;
  let currentSample: any = null;

  while (attempt < maxAttempts) {
    // 1. Generation
    let userPrompt = `Generate a research-grade sample for: ${topic}`;
    if (previousCritique && currentSample) {
      userPrompt += `\n\nPrevious attempt was rejected. Critique:\n${previousCritique}\n\nRefine the following sample to address the critique perfectly:\n${JSON.stringify(currentSample)}`;
    }

    const rawData = await LLMFactory.generateWithFallback(generatorConfigs, {
      systemInstruction: EXPERT_GENERATION_PROMPT,
      userPrompt: userPrompt,
      jsonSchema: schema
    });
    
    // Parse carefully in case of weird formatting
    let parsedData;
    try {
      parsedData = JSON.parse(rawData);
    } catch(e) {
      const match = rawData.match(/\{[\s\S]*\}/);
      if (match) {
        parsedData = JSON.parse(match[0]);
      } else {
        throw new Error("Failed to parse JSON output from generator");
      }
    }
    
    currentSample = parsedData;

    // 2. Critique & Scoring
    const critiqueSchema = {
      type: "object",
      properties: {
        accuracy: { type: "number" },
        depth: { type: "number" },
        originality: { type: "number" },
        consistency: { type: "number" },
        hallucination_free: { type: "number" },
        final_score: { type: "number" },
        critique: { type: "string" },
        is_accepted: { type: "boolean" }
      },
      required: ["accuracy", "depth", "originality", "consistency", "hallucination_free", "final_score", "critique", "is_accepted"]
    };

    const rawCritique = await LLMFactory.generateWithFallback(criticConfigs, {
      systemInstruction: EXPERT_CRITIQUE_PROMPT,
      userPrompt: `Critique this sample strictly:\n${JSON.stringify(currentSample)}`,
      jsonSchema: critiqueSchema
    });
    
    let score: QualityScore;
    try {
      score = JSON.parse(rawCritique);
    } catch(e) {
      const match = rawCritique.match(/\{[\s\S]*\}/);
      if (match) {
        score = JSON.parse(match[0]);
      } else {
        throw new Error("Failed to parse JSON output from critic");
      }
    }

    // 3. Filtering & Refinement Logic
    if (score.final_score >= 8.0 || score.is_accepted) {
      const semanticHash = crypto.createHash('md5').update(currentSample.answer || JSON.stringify(currentSample)).digest('hex');
      return {
        ...currentSample,
        quality_metrics: score,
        semantic_hash: semanticHash
      };
    } else if (score.final_score >= 6.5) {
      // Refine
      previousCritique = score.critique;
    } else {
      // Reject completely and start fresh
      previousCritique = null;
      currentSample = null;
    }

    attempt++;
  }
  return null; // Rejected after 3 attempts
}