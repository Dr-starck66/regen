export type LLMProviderName = 'gemini' | 'openai' | 'anthropic' | 'groq';

export interface ProviderConfig {
  provider: LLMProviderName;
  model: string;
  temperature?: number;
  apiKey?: string;
}

export interface GenerationRequest {
  category: string;
  size: number;
  providerConfig: ProviderConfig;
  expertMode: boolean;
}

export interface QualityScore {
  accuracy: number;     // 0-10
  depth: number;        // 0-10
  originality: number;  // 0-10
  consistency: number;  // 0-10
  hallucination_free: number; // 0-10
  final_score: number;  // 0-10
  critique: string;
  is_accepted: boolean;
}

export interface ExpertDatasetItem {
  instruction: string;
  context?: string;
  chain_of_thought: string;
  answer: string;
  quality_metrics: QualityScore;
  semantic_hash?: string;
}
