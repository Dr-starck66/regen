import React, { useState, useEffect } from 'react';
import { Database, Plus, RefreshCw, CheckCircle, FileText, Download, TrendingUp, Search, Shield, Stethoscope, Building, PieChart } from 'lucide-react';
import { cn } from './lib/utils';
import { FixedSizeList as List } from 'react-window';

const CATEGORIES = [
  { id: 'llm', name: 'LLM Fine-Tuning', icon: Database },
  { id: 'cybersecurity', name: 'Cybersécurité', icon: Shield },
  { id: 'financial', name: 'Finance & Marchés', icon: TrendingUp },
  { id: 'real-estate', name: 'Immobilier (IA)', icon: Building },
  { id: 'seo-marketing', name: 'SEO & Marketing', icon: Search },
  { id: 'medical', name: 'Médical & Scientifique', icon: Stethoscope },
  { id: 'computer-vision', name: 'Vision par Ordinateur', icon: PieChart },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'generate' | 'library'>('generate');
  
  // Form State
  const [category, setCategory] = useState(CATEGORIES[0].id);
  const [datasetName, setDatasetName] = useState('');
  const [size, setSize] = useState(10);
  const [temperature, setTemperature] = useState(0.8);
  const [expertMode, setExpertMode] = useState(false);
  const [provider, setProvider] = useState('gemini');
  const [model, setModel] = useState('gemini-3.6-pro');
  
  // Generation State
  const [isGenerating, setIsGenerating] = useState(false);
  const [step, setStep] = useState(0); // 0: Idle, 1: Generating, 2: Validating, 3: Enriching, 4: Done
  const [progress, setProgress] = useState(0);
  const [currentDataset, setCurrentDataset] = useState<any[]>([]);
  const [report, setReport] = useState<any>(null);
  const [enrichment, setEnrichment] = useState<any>(null);
  const [savedId, setSavedId] = useState<string | null>(null);

  // Library State
  const [datasets, setDatasets] = useState<any[]>([]);

  useEffect(() => {
    if (activeTab === 'library') {
      fetch('/api/datasets')
        .then(res => res.json())
        .then(data => setDatasets(data))
        .catch(console.error);
    }
  }, [activeTab]);

  const handleProviderChange = (newProvider: string) => {
    setProvider(newProvider);
    if (newProvider === 'gemini') setModel('gemini-3.6-pro');
    if (newProvider === 'openai') setModel('gpt-4o');
    if (newProvider === 'anthropic') setModel('claude-3-5-sonnet-20240620');
    if (newProvider === 'groq') setModel('llama3-70b-8192');
  };

  const handleGenerate = async () => {
    if (!datasetName) return alert("Veuillez entrer un nom de dataset");
    setIsGenerating(true);
    setStep(1);
    setProgress(10);
    setSavedId(null);
    setCurrentDataset([]);
    setReport(null);
    setEnrichment(null);

    try {
      // 1. Generate
      let allSamples: any[] = [];
      const BATCH_SIZE = expertMode ? size : 10; // If expert mode, handle size dynamically in backend since it does parallel mapped tasks
      const totalBatches = expertMode ? 1 : Math.ceil(size / BATCH_SIZE);
      
      for (let i = 0; i < totalBatches; i++) {
        const currentBatchSize = expertMode ? size : Math.min(BATCH_SIZE, size - (i * BATCH_SIZE));
        const genRes = await fetch('/api/generate-dataset', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            category, 
            size: currentBatchSize, 
            parameters: { 
              temperature,
              expertMode,
              providerConfig: expertMode ? { provider, model, temperature } : undefined
            } 
          })
        });
        const genData = await genRes.json();
        if (genData.error) throw new Error(genData.error);
        
        const samples = genData.samples || [];
        allSamples = [...allSamples, ...samples];
        setProgress(10 + Math.floor((20 / totalBatches) * (i + 1)));
      }
      
      setCurrentDataset(allSamples);

      // 2. Validate
      setStep(2);
      setProgress(40);
      const valRes = await fetch('/api/validate-dataset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ samples: allSamples, category })
      });
      const valData = await valRes.json();
      if (valData.error) throw new Error(valData.error);
      setReport(valData);

      // 3. Enrich
      setStep(3);
      setProgress(70);
      const enrRes = await fetch('/api/enrich-dataset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ samples: allSamples, category, name: datasetName })
      });
      const enrData = await enrRes.json();
      if (enrData.error) throw new Error(enrData.error);
      setEnrichment(enrData);

      // 4. Save
      setStep(4);
      setProgress(90);
      const saveRes = await fetch('/api/save-dataset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: datasetName,
          category,
          size: allSamples.length,
          qualityScore: valData.quality_score,
          price: enrData.estimated_price_euros,
          format: 'JSONL',
          metadata: {
            ...valData,
            tags: enrData.tags,
            product_description: enrData.product_description,
            readme: enrData.readme
          },
          samples: allSamples
        })
      });
      const saveData = await saveRes.json();
      if (saveData.id) setSavedId(saveData.id);
      
      setProgress(100);
    } catch (err: any) {
      alert("Erreur : " + err.message);
      setStep(0);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExport = async (id: string, name: string) => {
    try {
      const res = await fetch(`/api/export-dataset/${id}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${name.replace(/\s+/g, '_').toLowerCase()}_export.json`;
      a.click();
    } catch (err: any) {
      alert("Erreur d'exportation : " + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Database className="w-8 h-8 text-indigo-600" />
          <h1 className="text-2xl font-black tracking-tight text-slate-800">
            Nexus <span className="text-indigo-600">Data Factory</span>
          </h1>
        </div>
        <div className="flex gap-2 bg-slate-100 p-1 rounded-lg">
          <button 
            onClick={() => setActiveTab('generate')}
            className={cn("px-4 py-2 rounded-md text-sm font-semibold transition-all", activeTab === 'generate' ? "bg-white shadow-sm text-indigo-700" : "text-slate-500 hover:text-slate-700")}
          >
            Studio
          </button>
          <button 
            onClick={() => setActiveTab('library')}
            className={cn("px-4 py-2 rounded-md text-sm font-semibold transition-all", activeTab === 'library' ? "bg-white shadow-sm text-indigo-700" : "text-slate-500 hover:text-slate-700")}
          >
            Bibliothèque Marketplace
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        {activeTab === 'generate' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Panel: Configuration */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <h2 className="text-lg font-bold mb-4">Paramètres du Dataset</h2>
                
                <div className="space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-600 mb-2">Nom du Projet</label>
                    <input 
                      type="text" 
                      placeholder="ex: Sentiment Financier T3"
                      value={datasetName}
                      onChange={e => setDatasetName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-600 mb-2">Domaine d'Industrie</label>
                    <div className="grid grid-cols-1 gap-2">
                      {CATEGORIES.map(cat => (
                        <button
                          key={cat.id}
                          onClick={() => setCategory(cat.id)}
                          className={cn(
                            "flex items-center gap-3 px-4 py-3 rounded-xl border text-left transition-all",
                            category === cat.id 
                              ? "border-indigo-600 bg-indigo-50 text-indigo-800" 
                              : "border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-600"
                          )}
                        >
                          <cat.icon className="w-5 h-5" />
                          <span className="font-medium text-sm">{cat.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-600 mb-2">Taille de l'échantillon (Batch)</label>
                    <input 
                      type="number" 
                      min="1" max="100"
                      value={size}
                      onChange={e => setSize(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <div className="relative">
                        <input type="checkbox" className="sr-only" checked={expertMode} onChange={e => setExpertMode(e.target.checked)} />
                        <div className={cn("block w-10 h-6 rounded-full transition-colors", expertMode ? "bg-indigo-600" : "bg-slate-300")}></div>
                        <div className={cn("dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform", expertMode ? "transform translate-x-4" : "")}></div>
                      </div>
                      <span className="text-sm font-bold text-slate-700">Mode Expert (Research-Grade)</span>
                    </label>

                    {expertMode && (
                      <div className="space-y-4 pt-4 border-t border-slate-200">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Provider LLM</label>
                          <select 
                            value={provider} 
                            onChange={e => handleProviderChange(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          >
                            <option value="gemini">Google Gemini</option>
                            <option value="openai">OpenAI</option>
                            <option value="anthropic">Anthropic Claude</option>
                            <option value="groq">Groq (Llama)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">Modèle</label>
                          <input 
                            type="text" 
                            value={model} 
                            onChange={e => setModel(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <label className="block text-sm font-semibold text-slate-600">Température (Créativité)</label>
                      <span className="text-sm font-bold text-indigo-600">{temperature}</span>
                    </div>
                    <input 
                      type="range" 
                      min="0.1" max="1.5" step="0.1"
                      value={temperature}
                      onChange={e => setTemperature(Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>

                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating || !datasetName}
                    className="w-full py-4 rounded-xl bg-indigo-600 text-white font-bold text-lg hover:bg-indigo-700 active:scale-95 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isGenerating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Plus className="w-5 h-5" />}
                    {isGenerating ? 'Génération en cours...' : 'Générer le Dataset'}
                  </button>
                </div>
              </div>
            </div>

            {/* Right Panel: Pipeline Progress & Results */}
            <div className="lg:col-span-8 space-y-6">
              {step > 0 && (
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                  <h3 className="font-bold text-lg mb-4">Statut du Pipeline</h3>
                  <div className="flex gap-2 mb-2">
                    <div className={cn("flex-1 h-2 rounded-full", step >= 1 ? "bg-indigo-600" : "bg-slate-100")} />
                    <div className={cn("flex-1 h-2 rounded-full", step >= 2 ? "bg-indigo-600" : "bg-slate-100")} />
                    <div className={cn("flex-1 h-2 rounded-full", step >= 3 ? "bg-indigo-600" : "bg-slate-100")} />
                    <div className={cn("flex-1 h-2 rounded-full", step >= 4 ? "bg-indigo-600" : "bg-slate-100")} />
                  </div>
                  <div className="flex justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <span>1. Synthèse</span>
                    <span>2. Validation</span>
                    <span>3. Enrichissement</span>
                    <span>4. Packaging</span>
                  </div>
                </div>
              )}

              {report && enrichment && (
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-bold text-lg">Score de Qualité</h3>
                      <span className="text-3xl font-black text-emerald-500">{report.quality_score}</span>
                    </div>
                    <ul className="space-y-3 text-sm">
                      <li className="flex justify-between border-b pb-2">
                        <span className="text-slate-500">Doublons Détectés</span>
                        <span className="font-bold">{report.duplicates}</span>
                      </li>
                      <li className="flex justify-between border-b pb-2">
                        <span className="text-slate-500">Score de Biais (1-10)</span>
                        <span className="font-bold">{report.bias_score}</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-slate-500">Prêt pour l'Entraînement</span>
                        <span className="font-bold text-emerald-600">{report.training_ready ? 'Oui' : 'Non'}</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-bold text-lg">Valeur Commerciale</h3>
                      <span className="text-3xl font-black text-indigo-600">€{enrichment.estimated_price_euros}</span>
                    </div>
                    <div className="text-sm">
                      <p className="text-slate-600 mb-3">{enrichment.product_description}</p>
                      <div className="flex flex-wrap gap-2">
                        {enrichment.tags?.map((t: string) => (
                          <span key={t} className="px-2 py-1 bg-slate-100 text-slate-600 text-xs rounded-md">{t}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentDataset.length > 0 && (
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-lg">Aperçu des données ({currentDataset.length} lignes)</h3>
                    {savedId && (
                      <span className="flex items-center gap-1 text-emerald-600 text-sm font-semibold">
                        <CheckCircle className="w-4 h-4" /> Sauvegardé sur le Marketplace
                      </span>
                    )}
                  </div>
                  <div className="border border-slate-100 rounded-xl overflow-hidden bg-slate-50">
                    <List
                      height={500}
                      itemCount={currentDataset.length}
                      itemSize={350}
                      width="100%"
                    >
                      {({ index, style }) => {
                        const item = currentDataset[index];
                        const isExpert = !!item.quality_metrics;
                        return (
                          <div style={style} className="p-2">
                            <div className="h-full p-4 bg-white rounded-lg shadow-sm border border-slate-200 text-xs overflow-hidden flex flex-col">
                              {isExpert && (
                                <div className="flex flex-col gap-2 mb-3 pb-3 border-b border-slate-100">
                                  <div className="flex justify-between items-center">
                                    <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-1 rounded">Research-Grade 🔬</span>
                                    <span className={cn("px-2 py-1 rounded font-bold", item.quality_metrics.final_score >= 8 ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800")}>
                                      Score: {item.quality_metrics.final_score}/10 {item.quality_metrics.is_accepted ? "✓" : "↻ (Raffiné)"}
                                    </span>
                                  </div>
                                  <div className="grid grid-cols-5 gap-2 text-[10px] text-center font-semibold mt-1">
                                    <div className="bg-slate-50 p-1 rounded border border-slate-100">
                                      <div className="text-slate-400">Exact</div>
                                      <div className="text-slate-700">{item.quality_metrics.accuracy}</div>
                                    </div>
                                    <div className="bg-slate-50 p-1 rounded border border-slate-100">
                                      <div className="text-slate-400">Prof.</div>
                                      <div className="text-slate-700">{item.quality_metrics.depth}</div>
                                    </div>
                                    <div className="bg-slate-50 p-1 rounded border border-slate-100">
                                      <div className="text-slate-400">Orig.</div>
                                      <div className="text-slate-700">{item.quality_metrics.originality}</div>
                                    </div>
                                    <div className="bg-slate-50 p-1 rounded border border-slate-100">
                                      <div className="text-slate-400">Cohér.</div>
                                      <div className="text-slate-700">{item.quality_metrics.consistency}</div>
                                    </div>
                                    <div className="bg-slate-50 p-1 rounded border border-slate-100">
                                      <div className="text-slate-400">Sans Hallu.</div>
                                      <div className="text-slate-700">{item.quality_metrics.hallucination_free}</div>
                                    </div>
                                  </div>
                                </div>
                              )}
                              <pre className="font-mono flex-1 overflow-auto">{JSON.stringify(item, null, 2)}</pre>
                            </div>
                          </div>
                        );
                      }}
                    </List>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'library' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Bibliothèque Marketplace</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {datasets.map(d => (
                <div key={d.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-2 py-1 rounded-md">
                        {d.category}
                      </span>
                      <h3 className="font-bold text-lg mt-2">{d.name}</h3>
                    </div>
                    <span className="font-black text-slate-900">€{d.price}</span>
                  </div>
                  <p className="text-sm text-slate-500 mb-4 flex-1 line-clamp-3">
                    {d.metadata?.product_description || 'Dataset synthétique d\'IA.'}
                  </p>
                  
                  <div className="flex gap-4 text-xs font-semibold text-slate-400 mb-6">
                    <span className="flex items-center gap-1"><Database className="w-4 h-4"/> {d.size} lignes</span>
                    <span className="flex items-center gap-1"><CheckCircle className="w-4 h-4"/> Score: {d.qualityScore}</span>
                  </div>

                  <div className="flex gap-2">
                    <button onClick={() => handleExport(d.id, d.name)} className="flex-1 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all">
                      <Download className="w-4 h-4" /> Exporter
                    </button>
                    <button className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-xl text-sm font-bold flex items-center justify-center gap-2 hover:bg-slate-200 transition-all">
                      <FileText className="w-4 h-4" /> Docs
                    </button>
                  </div>
                </div>
              ))}
              {datasets.length === 0 && (
                <div className="col-span-full py-12 text-center text-slate-500">
                  Aucun dataset n'a été publié pour le moment.
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
