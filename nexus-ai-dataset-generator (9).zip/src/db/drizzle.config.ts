import { defineConfig } from 'drizzle-kit';

export default defineConfig({
  schema: './src/db/schema.ts',
  out: './src/db/migrations',
  dialect: 'postgresql',
  dbCredentials: {
    host: process.env.SQL_HOST || process.env.PGHOST!,
    user: process.env.SQL_ADMIN_USER || process.env.PGUSER!,
    password: process.env.SQL_ADMIN_PASSWORD || process.env.PGPASSWORD!,
    database: process.env.SQL_DB_NAME || process.env.PGDATABASE!,
    ssl: false
  },
});
