import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';

const pool = new Pool({
  host: process.env.SQL_HOST || process.env.PGHOST,
  user: process.env.SQL_USER || process.env.PGUSER,
  password: process.env.SQL_PASSWORD || process.env.PGPASSWORD,
  database: process.env.SQL_DB_NAME || process.env.PGDATABASE,
  port: process.env.SQL_HOST ? undefined : Number(process.env.PGPORT),
  ssl: process.env.SQL_HOST ? false : {
    rejectUnauthorized: true,
  },
});

export const db = drizzle(pool, { schema });
