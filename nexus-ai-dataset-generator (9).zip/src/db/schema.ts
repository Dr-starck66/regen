import { pgTable, text, timestamp, integer, boolean, uuid, jsonb, real } from 'drizzle-orm/pg-core';

export const datasets = pgTable('datasets', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  category: text('category').notNull(),
  size: integer('size').default(0),
  qualityScore: real('quality_score'),
  createdDate: timestamp('created_date').defaultNow(),
  version: text('version').default('1.0.0'),
  license: text('license').default('MIT'),
  price: integer('price').default(0),
  format: text('format').default('JSONL'),
  trainingReady: boolean('training_ready').default(false),
  metadata: jsonb('metadata')
});

export const datasetSamples = pgTable('dataset_samples', {
  id: uuid('id').defaultRandom().primaryKey(),
  datasetId: uuid('dataset_id').references(() => datasets.id, { onDelete: 'cascade' }),
  content: jsonb('content').notNull(),
  createdAt: timestamp('created_at').defaultNow()
});
