
import { GenerationConfig, DatasetItem } from "../types";

export const generateDatasetBatch = async (
  config: GenerationConfig,
  batchSize: number,
  batchIndex: number,
  previousExamples?: string,
  signal?: AbortSignal
): Promise<DatasetItem[]> => {
  const response = await fetch("/api/generate", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      config,
      batchSize,
      batchIndex,
      previousExamples
    }),
    signal
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `Failed to generate batch from server.`);
  }

  return response.json();
};

export const evaluateDataset = async (
  config: GenerationConfig,
  dataset: DatasetItem[]
) => {
  const response = await fetch("/api/evaluate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ config, dataset })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `Failed to evaluate dataset.`);
  }

  return response.json();
};

export const refineDatasetItem = async (
  config: GenerationConfig,
  item: DatasetItem,
): Promise<DatasetItem> => {
  const response = await fetch("/api/refine", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      config,
      item
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || `Failed to refine item.`);
  }

  return response.json();
};
